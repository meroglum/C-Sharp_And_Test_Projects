﻿using _2023._01._04_exercise;
using ShopAppExercise;
using System.Threading;

internal class Program
{
    private static void Main(string[] args)
    {
        PrompToConsole.CLIStore(); //Tüm sorguları çalıştır
    }
}